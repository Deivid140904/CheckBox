package com.example.checkbox;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.example.checkbox.R;

public class MainActivity extends AppCompatActivity {

    CheckBox cbArroz, cbLeite, cbCarne, cbFeijao, cbRefrigerante;
    Button btnTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cbArroz = findViewById(R.id.cbArroz);
        cbLeite = findViewById(R.id.cbLeite);
        cbCarne = findViewById(R.id.cbCarne);
        cbFeijao = findViewById(R.id.cbFeijao);
        cbRefrigerante = findViewById(R.id.cbRefrigerante);
        btnTotal = findViewById(R.id.btnTotal);

        btnTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double total = 0;

                if (cbArroz.isChecked()) {
                    total += 2.69;
                }
                if (cbLeite.isChecked()) {
                    total += 2.70;
                }
                if (cbCarne.isChecked()) {
                    total += 16.70;
                }
                if (cbFeijao.isChecked()) {
                    total += 3.38;
                }
                if (cbRefrigerante.isChecked()) {
                    total += 3.00;
                }

                // Mostra o valor total
                Toast.makeText(MainActivity.this,
                        "Valor Total: R$ " + String.format("%.2f", total),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
